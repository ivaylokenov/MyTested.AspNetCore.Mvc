﻿/// <autosync enabled="true" />
/// <reference path="../wwwroot/Scripts/bootstrap.js" />
/// <reference path="../wwwroot/Scripts/jquery.signalR-2.0.1.js" />
/// <reference path="../wwwroot/Scripts/jquery.validate.js" />
/// <reference path="../wwwroot/Scripts/jquery.validate.unobtrusive.js" />
/// <reference path="../wwwroot/Scripts/jquery-2.0.3.js" />
/// <reference path="../wwwroot/Scripts/modernizr-2.6.2.js" />
/// <reference path="../wwwroot/Scripts/respond.js" />
