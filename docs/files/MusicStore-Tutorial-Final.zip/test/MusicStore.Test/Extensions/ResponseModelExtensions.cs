﻿namespace MusicStore.Test.Extensions
{
    using MyTested.AspNetCore.Mvc.Builders.Base;
    using MyTested.AspNetCore.Mvc.Builders.Contracts.Base;
    using MyTested.AspNetCore.Mvc.Exceptions;
    using MyTested.AspNetCore.Mvc.Utilities;
    using MyTested.AspNetCore.Mvc.Utilities.Extensions;
    using System;
    using System.Collections.Generic;

    public static class ResponseModelExtensions
    {
        public static IBaseTestBuilderWithComponent WithCollectionModelOfType<TModel>(
            this IBaseTestBuilderWithResponseModel builder,
            Func<ICollection<TModel>, bool> predicate = null)
        {
            var actualBuilder = (BaseTestBuilderWithResponseModel)builder;
            var modelCollection = actualBuilder.GetActualModel<ICollection<TModel>>();
            
            if (predicate != null && !predicate(modelCollection))
            {
                var testContext = actualBuilder.TestContext;

                throw new ResponseModelAssertionException(string.Format(
                    "When calling {0} in {1} expected response model collection of {2} to pass the given predicate, but it failed.",
                    testContext.MethodName,
                    testContext.Component.GetName(),
                    typeof(TModel).ToFriendlyTypeName()));
            }

            return actualBuilder;
        }
    }
}
