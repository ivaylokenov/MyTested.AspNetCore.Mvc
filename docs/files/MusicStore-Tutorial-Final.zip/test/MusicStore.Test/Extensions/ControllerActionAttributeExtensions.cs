﻿namespace MusicStore.Test.Extensions
{
    using MyTested.AspNetCore.Mvc.Builders.Contracts.Attributes;

    public static class ControllerActionAttributeExtensions
    {
        public static TAttributesTestBuilder SpecifyingAdminArea<TAttributesTestBuilder>(
            this IControllerActionAttributesTestBuilder<TAttributesTestBuilder> builder)
            where TAttributesTestBuilder : IBaseAttributesTestBuilder<TAttributesTestBuilder>
            => builder.SpecifyingArea("Admin");
    }
}
