﻿namespace MusicStore.Test.ViewComponents
{
    using Components;
    using Models;
    using MyTested.AspNetCore.Mvc;
    using System.Collections.Generic;
    using System.Linq;
    using Xunit;

    public class CartSummaryComponentTest
    {
        [Fact]
        public void InvokingTheComponentShouldReturnCorrectCartItems()
            => MyViewComponent<CartSummaryComponent>
                .Instance()
                .WithSession(session => session
                    .WithEntry("Session", "TestCart"))
                .WithDbContext(db => db
                    .WithEntities(entities => entities
                        .AddRange(GetCartItems("TestCart", "TestAlbum"))))
                .InvokedWith(vc => vc.InvokeAsync())
                .ShouldHave()
                .ViewBag(viewBag => viewBag
                    .ContainingEntries(new
                    {
                        CartCount = 10,
                        CartSummary = "TestAlbum"
                    }))
                .AndAlso()
                .ShouldReturn()
                .View();
                

        private static IEnumerable<CartItem> GetCartItems(string cartId, string albumTitle)
        {
            var album = new Album { AlbumId = 1, Title = albumTitle };

            return Enumerable
                .Range(1, 10)
                .Select(n => new CartItem
                {
                    AlbumId = 1,
                    Album = album,
                    Count = 1,
                    CartId = cartId,
                });
        }
    }
}
