﻿namespace MusicStore.Test.Routing
{
    using Microsoft.Extensions.Caching.Memory;
    using Models;
    using MusicStore.Controllers;
    using MyTested.AspNetCore.Mvc;
    using Xunit;

    public class HomeRouteTest
    {
        [Fact]
        public void GetIndexActionShouldBeRoutedSuccessfuly()
            => MyRouting
                .Configuration()
                .ShouldMap("/Home")
                .To<HomeController>(c => c.Index(
                    With.Any<MusicStoreContext>(),
                    With.Any<IMemoryCache>()));

        [Fact]
        public void GetErrorActionShouldBeRoutedSuccessfuly()
            => MyRouting
                .Configuration()
                .ShouldMap("/Home/Error")
                .To<HomeController>(c => c.Error());
    }
}
