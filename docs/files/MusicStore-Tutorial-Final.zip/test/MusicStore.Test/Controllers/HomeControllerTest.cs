﻿namespace MusicStore.Test.Controllers
{
    using Extensions;
    using Microsoft.Extensions.Caching.Memory;
    using Microsoft.Extensions.DependencyInjection;
    using Models;
    using MusicStore.Controllers;
    using MyTested.AspNetCore.Mvc;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Xunit;

    public class HomeControllerTest
    {
        [Fact]
        public void HomeControllerShouldHaveNoAttributes()
            => MyController<HomeController>
                .Instance()
                .ShouldHave()
                .NoAttributes();

        [Fact]
        public void IndexShouldNotUseCacheIfOptionsDisableIt()
            => MyController<HomeController>
                .Instance()
                .WithOptions(options => options
                    .For<AppSettings>(settings => settings.CacheDbResults = false))
                .WithDbContext(db => db
                    .WithEntities(entities => entities.AddRange(Albums)))
                .Calling(c => c.Index(
                    From.Services<MusicStoreContext>(),
                    From.Services<IMemoryCache>()))
                .ShouldPassForThe<IServiceProvider>(services => Assert.Null(services
                    .GetRequiredService<IMemoryCache>().Get("topselling")));

        [Fact]
        public void IndexShouldSaveCorrectCacheEntriesIfOptionsEnableIt()
            => MyController<HomeController>
                .Instance()
                .WithOptions(options => options
                    .For<AppSettings>(settings => settings.CacheDbResults = true))
                .WithDbContext(db => db
                    .WithEntities(entities => entities.AddRange(Albums)))
                .Calling(c => c.Index(
                    From.Services<MusicStoreContext>(),
                    From.Services<IMemoryCache>()))
                .ShouldHave()
                .MemoryCache(cache => cache
                    .ContainingEntry(entry => entry
                        .WithKey("topselling")
                        .WithPriority(CacheItemPriority.High)
                        .WithAbsoluteExpirationRelativeToNow(TimeSpan.FromMinutes(10))
                        .WithValueOfType<List<Album>>()
                        .Passing(albums => albums.Count == 6)))
                .AndAlso()
                .ShouldReturn()
                .View()
                .WithCollectionModelOfType<Album>(albums => albums.Count == 6);

        [Fact]
        public void IndexShouldGetAlbumsFromCacheIfEntryExists()
            => MyController<HomeController>
                .Instance()
                .WithOptions(options => options
                    .For<AppSettings>(settings => settings.CacheDbResults = true))
                .WithMemoryCache(cache => cache
                    .WithEntry("topselling", Albums.Take(6).ToList()))
                .Calling(c => c.Index(
                    From.Services<MusicStoreContext>(),
                    From.Services<IMemoryCache>()))
                .ShouldReturn()
                .View()
                .WithModelOfType<List<Album>>()
                .Passing(albums => albums.Count == 6);

        [Fact]
        public void AccessDeniedShouldReturnOkStatusCodeAndProperView()
            => MyController<HomeController>
                .Instance()
                .Calling(c => c.AccessDenied())
                .ShouldHave()
                .HttpResponse(response => response
                    .WithStatusCode(HttpStatusCode.OK))
                .AndAlso()
                .ShouldReturn()
                .View("~/Views/Shared/AccessDenied.cshtml");

        private static Album[] Albums
        {
            get
            {
                var genres = Enumerable.Range(1, 10).Select(n =>
                new Genre()
                {
                    GenreId = n,
                    Name = "Genre Name " + n,
                }).ToArray();

                var artists = Enumerable.Range(1, 10).Select(n =>
                    new Artist()
                    {
                        ArtistId = n + 1,
                        Name = "Artist Name " + n,
                    }).ToArray();

                var albums = Enumerable.Range(1, 10).Select(n =>
                    new Album()
                    {
                        Artist = artists[n - 1],
                        ArtistId = n,
                        Genre = genres[n - 1],
                        GenreId = n,
                    }).ToArray();

                return albums;
            }
        }
    }
}
