﻿namespace MusicStore.Test.Controllers
{
    using Microsoft.Extensions.Options;
    using Mocks;
    using Models;
    using Moq;
    using MusicStore.Controllers;
    using MyTested.AspNetCore.Mvc;
    using System.Collections.Generic;
    using Xunit;

    public class StoreControllerTest : MyController<StoreController>
    {
        [Fact]
        public void IndexShouldReturnViewWithGenres()
            => Instance()
                .WithDbContext(dbContext => dbContext
                    .WithEntities(entities => entities.AddRange(
                        new Genre { Name = "FirstGenre" },
                        new Genre { Name = "SecondGenre" })))
                .Calling(c => c.Index())
                .ShouldReturn()
                .View()
                .WithModelOfType<List<Genre>>()
                .Passing(model => model.Count == 2);

        [Fact]
        public void BrowseShouldReturnNotFoundWithInvalidGenre()
            => Instance(new StoreController(
                    MockProvider.MusicStoreContext,
                    Mock.Of<IOptions<AppSettings>>()))
                .Calling(c => c.Browse("Invalid"))
                .ShouldReturn()
                .NotFound();

        [Fact]
        public void BrowseShouldReturnCorrectViewModelWithValidGenre()
            => Instance()
                .WithServices(
                    MockProvider.MusicStoreContext,
                    Mock.Of<IOptions<AppSettings>>())
                .Calling(c => c.Browse("Rap"))
                .ShouldReturn()
                .View()
                .WithModelOfType<Genre>()
                .Passing(model => model.GenreId == 2);
    }
}
