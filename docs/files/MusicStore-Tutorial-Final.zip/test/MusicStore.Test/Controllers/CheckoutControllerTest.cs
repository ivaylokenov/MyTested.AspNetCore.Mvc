﻿namespace MusicStore.Test.Controllers
{
    using Models;
    using MusicStore.Controllers;
    using MyTested.AspNetCore.Mvc;
    using System.Threading;
    using Xunit;

    public class CheckoutControllerTest
    {
        [Fact]
        public void CheckoutControllerShouldHaveAuthorizeAttribute()
            => MyController<CheckoutController>
                .Instance()
                .ShouldHave()
                .Attributes(attributes => attributes
                    .RestrictingForAuthorizedRequests());

        [Fact]
        public void AddressAndPaymentShouldReturnDefaultView()
            => MyController<CheckoutController>
                .Instance()
                .Calling(c => c.AddressAndPayment())
                .ShouldReturn()
                .View();

        [Fact]
        public void AddressAndPaymentShouldRerurnViewWithInvalidPostedPromoCode()
            => MyController<CheckoutController>
                .Instance()
                .WithHttpRequest(request => request
                    .WithFormField("PromoCode", "Invalid"))
                .Calling(c => c.AddressAndPayment(
                    From.Services<MusicStoreContext>(),
                    With.Default<Order>(),
                    CancellationToken.None))
                .ShouldHave()
                .ValidModelState()
                .AndAlso()
                .ShouldReturn()
                .View(With.Default<Order>());

        [Fact]
        public void AddressAndPaymentShouldRerurnRedirectWithValidData()
            => MyController<CheckoutController>
                .Instance()
                .WithHttpRequest(request => request
                    .WithFormField("PromoCode", "FREE"))
                .WithSession(session => session
                    .WithEntry("Session", "TestCart"))
                .WithAuthenticatedUser()
                .WithRouteData()
                .WithDbContext(db => db
                    .WithEntities(entities =>
                    {
                        var album = new Album { AlbumId = 1, Price = 10 };

                        var cartItem = new CartItem
                        {
                            Count = 1,
                            CartId = "TestCart",
                            AlbumId = 1,
                            Album = album
                        };

                        entities.Add(album);
                        entities.Add(cartItem);
                    }))
                .WithoutValidation()
                .Calling(c => c.AddressAndPayment(
                    From.Services<MusicStoreContext>(),
                    new Order { OrderId = 1 },
                    With.No<CancellationToken>()))
                .ShouldReturn()
                .Redirect()
                .To<CheckoutController>(c => c.Complete(With.Any<MusicStoreContext>(), 1));

        [Fact]
        public void CompleteShouldReturnViewWithCorrectIdWithFoundOrderForTheUser()
            => MyController<CheckoutController>
                .Instance()
                .WithAuthenticatedUser(user => user
                    .WithUsername("MyTestUser"))
                .WithDbContext(db => db
                    .WithEntities(entities => entities.Add(new Order
                    {
                        OrderId = 1,
                        Username = "MyTestUser"
                    })))
                .Calling(c => c.Complete(From.Services<MusicStoreContext>(), 1))
                .ShouldReturn()
                .View()
                .WithModel(1);
        
        [Fact]
        public void CompleteShouldReturnErrorViewWithInvalidOrderForTheUser()
            => MyController<CheckoutController>
                .Instance()
                .WithAuthenticatedUser(user => user
                    .WithUsername("InvalidUser"))
                .WithDbContext(db => db
                    .WithEntities(entities => entities.Add(new Order
                    {
                        OrderId = 1,
                        Username = "MyTestUser"
                    })))
                .Calling(c => c.Complete(From.Services<MusicStoreContext>(), 1))
                .ShouldReturn()
                .View("Error");
    }
}
