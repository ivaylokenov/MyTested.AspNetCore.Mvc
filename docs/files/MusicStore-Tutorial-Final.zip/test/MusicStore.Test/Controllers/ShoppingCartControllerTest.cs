﻿namespace MusicStore.Test.Controllers
{
    using Models;
    using MusicStore.Controllers;
    using MyTested.AspNetCore.Mvc;
    using System;
    using System.Linq;
    using Xunit;

    public class ShoppingCartControllerTest
    {
        [Fact]
        public void AddToCartShouldThrowExceptionWithInvalidId()
            => MyController<ShoppingCartController>
                .Instance()
                .Calling(c => c.AddToCart(1))
                .ShouldThrow()
                .AggregateException()
                .ContainingInnerExceptionOfType<InvalidOperationException>()
                .WithMessage()
#if NETCOREAPP1_0
                .Containing("Sequence contains no elements");
#else
                .Containing("One or more errors occurred");
#endif

        [Fact]
        public void AddToCartShouldPopulateSessionCartIfMissing()
            => MyController<ShoppingCartController>
                .Instance()
                .WithDbContext(db => db
                    .WithEntities(entities => entities
                        .Add(new Album { AlbumId = 1 })))
                .Calling(c => c.AddToCart(1))
                .ShouldHave()
                .Session(session => session
                    .ContainingEntryWithKey("Session"));

        [Fact]
        public void AddToCartShouldSaveTheAlbumsIntoDatabaseAndSession()
            => MyController<ShoppingCartController>
                .Instance()
                .WithSession(session => session.WithEntry("Session", "TestCart"))
                .WithDbContext(db => db
                    .WithEntities(entities => entities
                        .Add(new Album { AlbumId = 1 })))
                .Calling(c => c.AddToCart(1))
                .ShouldHave()
                .DbContext(db => db
                    .WithSet<CartItem>(cartItems => cartItems
                        .Any(a => a.AlbumId == 1 && a.CartId == "TestCart")))
                .AndAlso()
                .ShouldReturn()
                .Redirect()
                .ToAction(nameof(ShoppingCartController.Index));
    }
}
