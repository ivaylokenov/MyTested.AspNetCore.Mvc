﻿namespace MusicStore.Test.Controllers
{
    using Models;
    using MusicStore.Controllers;
    using MyTested.AspNetCore.Mvc;
    using Xunit;

    public class AccountControllerTest
    {
        [Fact]
        public void LoginShouldHaveCorrectAttributes()
            => MyController<AccountController>
                .Instance()
                .Calling(c => c.Login(
                    With.Default<LoginViewModel>(),
                    With.No<string>()))
                .ShouldHave()
                .ActionAttributes(attributes => attributes
                    .RestrictingForHttpMethod(HttpMethod.Post)
                    .AllowingAnonymousRequests()
                    .ValidatingAntiForgeryToken());

        [Fact]
        public void LoginShouldHaveReturnUrlInTheViewBag()
        {
            var returnUrl = "Test/Return/Url";

            MyController<AccountController>
                .Instance()
                .Calling(c => c.Login(returnUrl))
                .ShouldHave()
                .ViewBag(viewBag => viewBag
                    .ContainingEntry("ReturnUrl", returnUrl))
                .AndAlso()
                .ShouldReturn()
                .View();
        }

        [Fact]
        public void LoginShouldReturnRedirectToLocalWithValidLoginViewModel()
        {
            var model = new LoginViewModel
            {
                Email = "valid@valid.com",
                Password = "valid"
            };

            var redirectUrl = "/Test/Url";

            MyController<AccountController>
                .Instance()
                .Calling(c => c.Login(model, redirectUrl))
                .ShouldHave()
                .ValidModelState()
                .AndAlso()
                .ShouldReturn()
                .Redirect()
                .ToUrl(redirectUrl);
        }

        [Fact]
        public void LoginShouldReturnViewWithSameModelWithInvalidLoginViewModel()
        {
            var model = new LoginViewModel
            {
                Email = "invalid@invalid.com",
                Password = "invalid"
            };

            var redirectUrl = "/Test/Url";

            MyController<AccountController>
                .Instance()
                .Calling(c => c.Login(model, redirectUrl))
                .ShouldHave()
                .ModelState(modelState => modelState
                    .ContainingError(string.Empty)
                    .ThatEquals("Invalid login attempt."))
                .AndAlso()
                .ShouldReturn()
                .View(model);
        }

        [Fact]
        public void ExternalLoginShouldReturnCorrectResult()
            => MyController<AccountController>
                .Instance()
                .WithRouteData()
                .Calling(c => c.ExternalLogin("TestProvider", "TestReturnUrl"))
                .ShouldReturn()
                .Challenge();
    }
}
