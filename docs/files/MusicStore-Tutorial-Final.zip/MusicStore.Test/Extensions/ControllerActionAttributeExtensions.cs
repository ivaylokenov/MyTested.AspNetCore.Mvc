﻿namespace MusicStore.Test.Extensions
{
    using MyTested.AspNetCore.Mvc;
    using MyTested.AspNetCore.Mvc.Builders.Contracts.Attributes;

    public static class ControllerActionAttributeExtensions
    {
        public static TAttributesTestBuilder SpecifyingAdminArea<TAttributesTestBuilder>(
            this IControllerActionAttributesTestBuilder<TAttributesTestBuilder> builder)
            where TAttributesTestBuilder : IControllerActionAttributesTestBuilder<TAttributesTestBuilder>
            => builder.SpecifyingArea("Admin");
    }
}
