﻿namespace MusicStore.Test.Controllers
{
    using MusicStore.Controllers;
    using MusicStore.Models;
    using MyTested.AspNetCore.Mvc;
    using Xunit;

    public class ManageControllerTest
    {
        [Fact]
        public void RemoveLoginShouldReturnRedirectToActionWithNoUser()
            => MyController<ManageController>
                .Instance()
                .Calling(c => c.RemoveLogin(With.No<string>(), With.No<string>()))
                .ShouldReturn()
                .Redirect(redirect => redirect
                    .ToAction(nameof(ManageController.ManageLogins))
                    .ContainingRouteValues(new { Message = ManageController.ManageMessageId.Error }));

        [Fact]
        public void ChangePasswordShouldReturnViewWithSameModelWithInvalidModelState()
        {
            var model = new ChangePasswordViewModel();

            MyController<ManageController>
                .Instance()
                .Calling(c => c.ChangePassword(model))
                .ShouldHave()
                .InvalidModelState()
                .AndAlso()
                .ShouldReturn()
                .View(result => result
                    .WithModelOfType<ChangePasswordViewModel>()
                    .Passing(viewModel => viewModel == model));
        }
    }
}
