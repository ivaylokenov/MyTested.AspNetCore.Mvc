﻿namespace MusicStore.Test.Routing
{
    using MusicStore.Controllers;
    using MyTested.AspNetCore.Mvc;
    using Xunit;

    public class StoreRouteTest
    {
        [Fact]
        public void GetBrowseActionShouldBeRoutedSuccessfuly()
            => MyRouting
                .Configuration()
                .ShouldMap("/Store/Browse?genre=HipHop")
                .To<StoreController>(c => c.Browse("HipHop"));
    }
}
