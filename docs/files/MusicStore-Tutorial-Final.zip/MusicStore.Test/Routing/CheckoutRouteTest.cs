﻿namespace MusicStore.Test.Routing
{
    using MusicStore.Controllers;
    using MyTested.AspNetCore.Mvc;
    using Xunit;

    public class CheckoutRouteTest
    {
        [Fact]
        public void GetAddressAndPaymentActionShouldBeRoutedSuccessfuly()
            => MyRouting
                .Configuration()
                .ShouldMap(request => request
                    .WithLocation("/Checkout/AddressAndPayment")
                    .WithUser())
                .To<CheckoutController>(c => c.AddressAndPayment());
    }
}
